import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportadcp',
  templateUrl: './reportadcp.component.html',
  styleUrls: ['./reportadcp.component.css']
})
export class ReportadcpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

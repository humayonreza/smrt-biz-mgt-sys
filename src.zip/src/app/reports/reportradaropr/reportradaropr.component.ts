import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportradaropr',
  templateUrl: './reportradaropr.component.html',
  styleUrls: ['./reportradaropr.component.css']
})
export class ReportradaroprComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

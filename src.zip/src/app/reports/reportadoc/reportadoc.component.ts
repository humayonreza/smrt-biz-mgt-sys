import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportadoc',
  templateUrl: './reportadoc.component.html',
  styleUrls: ['./reportadoc.component.css']
})
export class ReportadocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

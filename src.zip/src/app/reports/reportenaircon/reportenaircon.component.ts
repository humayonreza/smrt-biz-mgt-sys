import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportenaircon',
  templateUrl: './reportenaircon.component.html',
  styleUrls: ['./reportenaircon.component.css']
})
export class ReportenairconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

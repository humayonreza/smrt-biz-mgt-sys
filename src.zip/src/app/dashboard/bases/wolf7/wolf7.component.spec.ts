import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Wolf7Component } from './wolf7.component';

describe('Wolf7Component', () => {
  let component: Wolf7Component;
  let fixture: ComponentFixture<Wolf7Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Wolf7Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Wolf7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
